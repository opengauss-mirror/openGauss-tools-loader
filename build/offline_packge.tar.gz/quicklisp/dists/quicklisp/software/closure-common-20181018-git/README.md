# closure-common

This is a fork of Gilbert Baumann's closure-common library, originally found here: http://www.cliki.net/closure-common

The source hadn't been updated in a while and it doesn't seem that Gilbert Baumann or David Lichteblau is actively maintaing the project. Hence, this fork.
