-------------------------------------------
DRAKMA - HTTP client written in Common Lisp
-------------------------------------------

DRAKMA is a HTTP client written in Common Lisp.  Please visit [the
documentation site](http://edicl.github.io/drakma/) for more information.

[![Gitter](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/edicl/drakma?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)
