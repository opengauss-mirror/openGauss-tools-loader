# 1.0.6
  Fixed bug printing when *quote-escape* is null

  AccelerationNet/cl-csv/issues/29
