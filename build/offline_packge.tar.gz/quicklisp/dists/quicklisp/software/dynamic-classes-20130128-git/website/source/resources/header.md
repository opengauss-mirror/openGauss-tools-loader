{include shared-links.md}

{set-property html yes}
{set-property style-sheet "http://common-lisp.net/project/cl-containers/shared/style.css"}
{set-property author "Gary Warren King"}
{set-property title "Dynamic-Classes | metabang.com"}

 [devel-list]: http://common-lisp.net/cgi-bin/mailman/listinfo/dynamic-classes-devel
 [cliki-home]: http://www.cliki.net/dynamic-classes
 [tarball]: http://common-lisp.net/project/dynamic-classes/dynamic-classes.tar.gz
  
<div id="header">
	<span class="logo"><a href="http://www.metabang.com/" title="metabang.com"><img src="http://common-lisp.net/project/cl-containers/shared/metabang-2.png" title="metabang.com" width="100" alt="Metabang Logo" /></a></span>

## Dynamic-Classes

#### Classes how you want them, when you want them

</div>
