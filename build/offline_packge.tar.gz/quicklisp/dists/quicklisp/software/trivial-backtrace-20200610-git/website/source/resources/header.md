{include shared-links.md}

{set-property html yes}
{set-property style-sheet "styles.css"}
{set-property author "Gary Warren King"}
{set-property title "trivial-backtrace | watch where you've been"}

 [devel-list]: http://common-lisp.net/cgi-bin/mailman/listinfo/trivial-backtrace-devel
 [cliki-home]: http://www.cliki.net//trivial-backtrace
 [tarball]: http://common-lisp.net/project/trivial-backtrace/trivial-backtrace.tar.gz
  
<div id="header">
	<span class="logo"><a href="http://www.metabang.com/" title="metabang.com"><img src="http://common-lisp.net/project/cl-containers/shared/metabang-2.png" title="metabang.com" width="100" alt="Metabang Logo" /></a></span>

## trivial-backtrace

#### watch where you've been

</div>
