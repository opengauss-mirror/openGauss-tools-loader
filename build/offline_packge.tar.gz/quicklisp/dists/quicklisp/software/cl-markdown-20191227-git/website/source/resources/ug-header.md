{set-property html yes}
{set-property style-sheet user-guide}

  [darcs]: http://www.darcs.net/
  [asdf-install]: http://common-lisp.net/project/asdf-install
  [tarball]: http://common-lisp.net/project/cl-markdown/cl-markdown_latest.tar.gz
  [gwking]: http://www.metabang.com/
  [cl-markdown-cliki]: http://www.cliki.net/cl-markdown
  [user-guide]: user-guide.html
  
<div id="header">
{include resources/ug-navigation.md}
</div>
