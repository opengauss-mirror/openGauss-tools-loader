<div id="footer">
{include resources/ug-navigation.md}

### Copyright (c) 2007 - 2008 Gary Warren King (gwking@metabang.com) 

CL-Markdown has an MIT style license

<br>
<div id="timestamp">Last updated {today} at {now}</div>
</div>
