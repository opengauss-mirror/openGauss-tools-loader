YASON
=====

> YASON is a Common Lisp library for encoding and decoding data in the
> [JSON](https://raw.github.com/phmarek/clixdoc/master/clixdoc.xsl)
> interchange format.  JSON is used as a lightweight alternative to
> XML.  YASON has the sole purpose of encoding and decoding data and
> does not impose any object model on the Common Lisp application that
> uses it.

Please proceed to the [Documentation](http://phmarek.github.io/yason)

This project was maintained by https://github.com/hanshuebner/ until 2019.
