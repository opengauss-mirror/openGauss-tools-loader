{set-property html yes}
{set-property style-sheet user-guide}
{set-property author "Gary Warren King"}

<div id="header">
{include navigation.md}
</div>

{include shared.md}
