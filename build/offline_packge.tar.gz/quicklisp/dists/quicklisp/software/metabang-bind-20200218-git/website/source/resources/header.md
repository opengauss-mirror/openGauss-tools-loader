{set-property html yes}
{set-property style-sheet "http://common-lisp.net/project/cl-containers/shared/style-200.css"}
{set-property author "Gary Warren King"}

{include shared.md}
{include shared-links.md}

<div id="header">
	<span class="logo"><a href="http://www.metabang.com/" title="metabang.com"><img src="http://common-lisp.net/project/cl-containers/shared/metabang-2.png" title="metabang.com" width="100" alt="Metabang Logo" /></a></span>

## metabang-bind

#### Sticking the pedal to the metal fun

</div>

  [tr]: test-report.html

  [user-guide]: user-guide.html
  
  [tarball]: http://common-lisp.net/project/cl-containers/bundler/bundler_latest.tar.gz  
  [metabang-bind-tar]: http://common-lisp.net/project/metabang-bind/metabang-bind_latest.tar.gz

  [devel-list]: http://common-lisp.net/cgi-bin/mailman/listinfo/metabang-bind-devel
  [cliki-home]: http://www.cliki.net//metabang-bind
  [tarball]: http://common-lisp.net/project/metabang-bind/metabang-bind.tar.gz
